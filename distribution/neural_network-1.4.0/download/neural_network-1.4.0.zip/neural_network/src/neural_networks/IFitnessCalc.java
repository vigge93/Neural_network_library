package neural_networks;

public interface IFitnessCalc {
	float fitness();
	void calcFitness();
}