package neural_networks;

public interface ICopy<T> {
	T copy();
}
