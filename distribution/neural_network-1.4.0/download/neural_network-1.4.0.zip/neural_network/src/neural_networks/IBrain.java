package neural_networks;

public interface IBrain {
	ENN getBrain();
}
