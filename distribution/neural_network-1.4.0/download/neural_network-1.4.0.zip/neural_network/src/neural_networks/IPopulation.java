/**
 * 
 */
package neural_networks;

/**
 * @author Victor
 * Interface for the Population class
 */
public interface IPopulation<T> {
	boolean Active();
	T Factory();
	T Copy();
	float Fitness();
	void CalcFitness();
	void ThinkWrapper();
	ENN GetBrain();
}
