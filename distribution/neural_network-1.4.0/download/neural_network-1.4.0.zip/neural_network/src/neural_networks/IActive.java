package neural_networks;

public interface IActive {
	boolean Active();
}
