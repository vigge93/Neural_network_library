package neural_networks;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Evolving_neural_network extends Neural_network implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public float mutationRate = (float)0.01;
    
	public float fitness;
	
    public Evolving_neural_network(int inputs_, int[] hidden_, int outputs_, String activation) {
        super(inputs_, hidden_, outputs_, activation);
    }

    public Evolving_neural_network(Evolving_neural_network parent) {
        super();
        this.inputs = new Matrix(parent.inputs);
        this.hidden = new Matrix[parent.hidden.length];
        for (int i = 0; i < this.hidden.length; i++) {
            this.hidden[i] = new Matrix(parent.hidden[i]);
        }
        this.outputs = new Matrix(parent.outputs);

        this.weightsIH = new Matrix(parent.weightsIH);
        this.weightsHH = new Matrix[parent.weightsHH.length];
        for (int i = 0; i < this.weightsHH.length; i++) {
            this.weightsHH[i] = new Matrix(parent.weightsHH[i]);
        }
        this.weightsHO = new Matrix(parent.weightsHO);

        this.weightBI = new Matrix(parent.weightBI);
        this.weightsBH = new Matrix[parent.weightsBH.length];
        for (int i = 0; i < this.weightsBH.length; i++) {
            this.weightsBH[i] = new Matrix(parent.weightsBH[i]);
        }
        this.weightBO = new Matrix(parent.weightBO);

        this.mutationRate = parent.mutationRate;
        this.activation = parent.activation;
    }

    public Evolving_neural_network copy() {
        return new Evolving_neural_network(this);
    }

    public void mutate() {
        mutate(weightsIH);
        for (int i = 0; i < weightsHH.length; i++) {
            mutate(weightsHH[i]);
        }
        mutate(weightsHO);

        mutate(weightBI);
        for (int i = 0; i < weightsBH.length; i++) {
            mutate(weightsBH[i]);
        }
        mutate(weightBO);
    }

    protected void mutate(Matrix m) {
        for (int i = 0; i < m.rows; i++) {
            for (int j = 0; j < m.cols; j++) {
                if ((float)Math.random() < mutationRate) {
                    m.table[i][j] = (float)Math.random() * 2 - 1;
                }
            }
        }
    }
    
    public static Evolving_neural_network load(String filename) {
    	Evolving_neural_network res = null;
        try {
            FileInputStream fileIn = new FileInputStream(filename);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            res = (Evolving_neural_network) objectIn.readObject();
            objectIn.close();
            fileIn.close();
        } 
        catch (IOException e) {
            e.printStackTrace();
        } 
        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return res;
    }

    public void save(String filename) {
        try {
            FileOutputStream fileOut = new FileOutputStream(filename);
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(this);
            objectOut.close();
            fileOut.close();
        } 
        catch (IOException i) {
            i.printStackTrace();
        }
    }
}