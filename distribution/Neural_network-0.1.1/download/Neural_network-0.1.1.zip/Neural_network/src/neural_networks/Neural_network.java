package neural_networks;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Neural_network implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected float sigmoid(float val) {
		return 1 / (1 + (float) Math.exp(-val));
	}

	protected float dsigmoid(float val) {
		return val * (1 - val);
	}

	protected Matrix softmax(Matrix m) {
		Matrix res = new Matrix(m);
		float total = 0;
		for (int i = 0; i < m.rows; i++) {
			float exp_value = (float) Math.exp(m.table[i][0]);
			res.table[i][0] = exp_value;
			total += exp_value;
		}
		for (int i = 0; i < res.rows; i++) {
			res.table[i][0] /= total;
		}
		return res;
	}

	protected float softmax(int val, float total) {
		return (float) (Math.exp(val) / total);
	}

	protected Matrix dSoftmax(Matrix m) {
		Matrix res = new Matrix(m);
		res = softmax(res);
		for (int i = 0; i < res.rows; i++) {
			float val = res.table[i][0];
		}
		return res;
	}

	protected float crossentropy_loss(Matrix answer, Matrix predicted) {
		float sum = 0;
		for (int i = 0; i < answer.rows; i++) {
			sum += answer.table[i][0] * (float) Math.log(predicted.table[i][0]);
		}
		return -sum;
	}

	protected int kronecker_delta(int a, int b) {
		return a == b ? 1 : 0;
	}

	protected static final int SIGMOID = 0;
	protected static final int SOFTMAXSIG = 1;
	protected static final int TANH = 2;
	protected static final int SOFTMAXTANH = 3;
	protected static final int GAUSSIAN = 4;
	protected static final int SOFTMAXGAUSSIAN = 5;

	protected Matrix inputs;
	protected Matrix[] hidden;
	protected Matrix outputs;

	protected Matrix weightsIH;
	protected Matrix[] weightsHH;
	protected Matrix weightsHO;

	protected Matrix weightBI;
	protected Matrix[] weightsBH;
	protected Matrix weightBO;

	protected int activation;

	/**
	 * 
	 * @param inputs_    Number of input nodes
	 * @param hidden_    Array of hidden nodes per layer
	 * @param outputs_   Number of output nodes
	 * @param activation Which activation function/s to use
	 * 
	 */
	public Neural_network(int inputs_, int[] hidden_, int outputs_, String activation) {
		switch (activation) {
		case "sigmoid":
			this.activation = SIGMOID;
			break;
		case "softmax_sigmoid":
			this.activation = SOFTMAXSIG;
			break;
		case "tanh":
			this.activation = TANH;
			break;
		case "softmax_tanh":
			this.activation = SOFTMAXTANH;
			break;
		case "gaussian":
			this.activation = GAUSSIAN;
			break;
		case "softmax_gaussian":
			this.activation = SOFTMAXGAUSSIAN;
			break;
		default:
			this.activation = SIGMOID;
			break;
		}
		hidden = new Matrix[hidden_.length];

		inputs = new Matrix(inputs_, 1);
		for (int i = 0; i < hidden.length; i++) {
			hidden[i] = new Matrix(hidden_[i], 1);
		}
		outputs = new Matrix(outputs_, 1);

		weightsHH = new Matrix[hidden_.length - 1];
		weightsBH = new Matrix[hidden_.length - 1];

		weightsIH = new Matrix(hidden_[0], inputs_);
		weightsIH.randomize();
		for (int i = 0; i < hidden.length - 1; i++) {
			weightsHH[i] = new Matrix(hidden[i + 1].rows, hidden[i].rows);
			weightsHH[i].randomize();
			weightsBH[i] = new Matrix(hidden[i + 1].rows, 1);
			weightsBH[i].randomize();
		}
		weightsHO = new Matrix(outputs_, hidden_[hidden_.length - 1]);
		weightsHO.randomize();

		weightBI = new Matrix(hidden_[0], 1);
		weightBI.randomize();
		weightBO = new Matrix(outputs_, 1);
		weightBO.randomize();
	}

	public Neural_network() {
	}

	/**
	 * 
	 * @param in Input vector
	 * @return float[] Output vector
	 */
	public float[] guess(float[] in) {
		Matrix inputs_ = new Matrix(in);
		Matrix[] hidden_ = new Matrix[hidden.length];
		for (int i = 0; i < hidden_.length; i++) {
			hidden_[i] = new Matrix(hidden[i]);
		}
		Matrix outputs_ = new Matrix(outputs);

		Matrix weightsIH_ = new Matrix(weightsIH);
		Matrix weightBI_ = new Matrix(weightBI);
		Matrix weightBO_ = new Matrix(weightBO);

		Matrix[] weightsHH_ = new Matrix[weightsHH.length];
		for (int i = 0; i < weightsHH_.length; i++) {
			weightsHH_[i] = new Matrix(weightsHH[i]);
		}
		Matrix[] weightsBH_ = new Matrix[weightsBH.length];
		for (int i = 0; i < weightsBH_.length; i++) {
			weightsBH_[i] = new Matrix(weightsBH[i]);
		}
		Matrix weightsHO_ = new Matrix(weightsHO);
		// Input to hidden
		Matrix tempIH = Matrix.multiply(weightsIH_, inputs_);
		tempIH = Matrix.add(tempIH, weightBI_);

		// Activation
		switch (activation) {
		case SIGMOID:
			for (int i = 0; i < tempIH.rows; i++) {
				hidden_[0].table[i][0] = sigmoid(tempIH.table[i][0]);
			}
			break;
		case SOFTMAXSIG:
			for (int i = 0; i < tempIH.rows; i++) {
				hidden_[0].table[i][0] = sigmoid(tempIH.table[i][0]);
			}
			break;
		case TANH:
			break;
		case SOFTMAXTANH:
			break;
		case GAUSSIAN:
			break;
		case SOFTMAXGAUSSIAN:
			break;
		default:
			for (int i = 0; i < tempIH.rows; i++) {
				hidden_[0].table[i][0] = sigmoid(tempIH.table[i][0]);
			}
			break;
		}

		// Hidden to hidden
		for (int n = 0; n < weightsHH_.length; n++) {
			Matrix tempHH = Matrix.multiply(weightsHH_[n], hidden_[n]);
			tempHH = Matrix.add(tempHH, weightsBH_[n]);

			// Activation

			switch (activation) {
			case SIGMOID:
				for (int i = 0; i < tempHH.rows; i++) {
					hidden_[n + 1].table[i][0] = sigmoid(tempHH.table[i][0]);
				}
				break;
			case SOFTMAXSIG:
				for (int i = 0; i < tempHH.rows; i++) {
					hidden_[n + 1].table[i][0] = sigmoid(tempHH.table[i][0]);
				}
				break;
			case TANH:
				break;
			case SOFTMAXTANH:
				break;
			case GAUSSIAN:
				break;
			case SOFTMAXGAUSSIAN:
				break;
			default:
				for (int i = 0; i < tempHH.rows; i++) {
					hidden_[n + 1].table[i][0] = sigmoid(tempHH.table[i][0]);
				}
				break;
			}
		}

		// Hidden to outputs
		Matrix tempHO = Matrix.multiply(weightsHO_, hidden_[hidden_.length - 1]);
		tempHO = Matrix.add(tempHO, weightBO_);
		for (int i = 0; i < tempHO.rows; i++) {

			// Activation

			switch (activation) {
			case SIGMOID:
				for (int j = 0; j < tempHO.cols; j++) {
					outputs_.table[i][j] = sigmoid(tempHO.table[i][j]);
				}
				break;
			case SOFTMAXSIG:
				outputs_ = softmax(outputs_);
				break;
			case TANH:
				break;
			case SOFTMAXTANH:
				outputs_ = softmax(outputs_);
				break;
			case GAUSSIAN:
				break;
			case SOFTMAXGAUSSIAN:
				outputs_ = softmax(outputs_);
				break;
			default:
				for (int j = 0; j < tempHO.cols; j++) {
					outputs_.table[i][j] = sigmoid(tempHO.table[i][j]);
				}
				break;
			}
		}
		return outputs_.toArray();
	}
	
	public static Neural_network load(String filename) {
		Neural_network res = null;
		try {
			FileInputStream fileIn = new FileInputStream(filename);
			ObjectInputStream objectIn = new ObjectInputStream(fileIn);
			res = (Neural_network) objectIn.readObject();
			objectIn.close();
			fileIn.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return res;
	}

	public void save(String filename) {
		try {
			FileOutputStream fileOut = new FileOutputStream(filename);
			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
			objectOut.writeObject(this);
			objectOut.close();
			fileOut.close();

		} catch (IOException i) {
			i.printStackTrace();
		}
	}

	/**
	 * 
	 * @param arr Array to analyze
	 * @return float[] [index, value at index]
	 */
	public static float[] get_max(float[] arr) {
		int index = -1;
		float max = Float.NEGATIVE_INFINITY;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > max) {
				max = arr[i];
				index = i;
			}
		}
		float[] res = { index, arr[index] };
		return res;
	}
}