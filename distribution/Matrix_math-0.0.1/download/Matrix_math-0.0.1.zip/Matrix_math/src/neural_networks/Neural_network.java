package neural_networks;

public class Neural_network {

	private float sigmoid(float val) {
		return 1 / (1 + (float) Math.exp(-val));
	}

	private float dsigmoid(float val) {
		return val * (1 - val);
	}

	private Matrix softmax(Matrix m) {
		Matrix res = new Matrix(m);
		float total = 0;
		for (int i = 0; i < m.rows; i++) {
			float exp_value = (float) Math.exp(m.table[i][0]);
			res.table[i][0] = exp_value;
			total += exp_value;
		}
		for (int i = 0; i < res.rows; i++) {
			res.table[i][0] /= total;
		}
		return res;
	}
	
	private float softmax(int val, float total) {
		return (float) (Math.exp(val)/total);
	}

	private Matrix dSoftmax(Matrix m) {
		Matrix res = new Matrix(m);
		res = softmax(res);
		for (int i = 0; i < res.rows; i++) {
			float val = res.table[i][0];
			
		}
		return res;
	}

	private int kronecker_delta(int a, int b) {
		return a == b ? 1 : 0;
	}
	
	private static final int SIGMOID = 0;
	private static final int SOFTMAXSIG = 1;
	private static final int TANH = 2;
	private static final int SOFTMAXTANH = 3;
	private static final int GAUSSIAN = 4;
	private static final int SOFTMAXGAUSSIAN = 5;
	
	private Matrix inputs;
	private Matrix[] hidden;
	private Matrix outputs;

	private Matrix weightsIH;
	private Matrix weightBI;
	private Matrix weightBO;

	private Matrix[] weightsHH;
	private Matrix[] weightsBH;
	private Matrix weightsHO;

	public float learningrate = (float) 0.01;
	private int activation;

	/**
	 * 
	 * @param inputs_  Input nodes
	 * @param hidden_  Hidden layers
	 * @param outputs_ Output nodes
	 * @param activation Which activation function/s to use
	 */
	public Neural_network(int inputs_, int[] hidden_, int outputs_, int activation) {
		hidden = new Matrix[hidden_.length];

		inputs = new Matrix(inputs_, 1);
		for (int i = 0; i < hidden.length; i++) {
			hidden[i] = new Matrix(hidden_[i], 1);
		}
		outputs = new Matrix(outputs_, 1);

		weightsHH = new Matrix[hidden_.length - 1];
		weightsBH = new Matrix[hidden_.length - 1];

		weightsIH = new Matrix(hidden_[0], inputs_);
		weightsIH.randomize();
		for (int i = 0; i < hidden.length - 1; i++) {
			weightsHH[i] = new Matrix(hidden[i + 1].rows, hidden[i].rows);
			weightsHH[i].randomize();
			weightsBH[i] = new Matrix(hidden[i + 1].rows, 1);
			weightsBH[i].randomize();
		}
		weightsHO = new Matrix(outputs_, hidden_[hidden_.length - 1]);
		weightsHO.randomize();

		weightBI = new Matrix(hidden_[0], 1);
		weightBI.randomize();
		weightBO = new Matrix(outputs_, 1);
		weightBO.randomize();
	}

	public float[] guess(float[] in) {
		Matrix inputs_ = new Matrix(in);
		Matrix[] hidden_ = new Matrix[hidden.length];
		for (int i = 0; i < hidden_.length; i++) {
			hidden_[i] = new Matrix(hidden[i]);
		}
		Matrix outputs_ = new Matrix(outputs);

		Matrix weightsIH_ = new Matrix(weightsIH);
		Matrix weightBI_ = new Matrix(weightBI);
		Matrix weightBO_ = new Matrix(weightBO);

		Matrix[] weightsHH_ = new Matrix[weightsHH.length];
		for (int i = 0; i < weightsHH_.length; i++) {
			weightsHH_[i] = new Matrix(weightsHH[i]);
		}
		Matrix[] weightsBH_ = new Matrix[weightsBH.length];
		for (int i = 0; i < weightsBH_.length; i++) {
			weightsBH_[i] = new Matrix(weightsBH[i]);
		}
		Matrix weightsHO_ = new Matrix(weightsHO);
		// Input to hidden
		Matrix tempIH = Matrix.multiply(weightsIH_, inputs_);
		tempIH = Matrix.add(tempIH, weightBI_);
		for (int i = 0; i < tempIH.rows; i++) {
			hidden_[0].table[i][0] = sigmoid(tempIH.table[i][0]);
		}

		// Hidden to hidden
		for (int n = 0; n < weightsHH_.length; n++) {
			Matrix tempHH = Matrix.multiply(weightsHH_[n], hidden_[n]);
			tempHH = Matrix.add(tempHH, weightsBH_[n]);
			for (int i = 0; i < tempHH.rows; i++) {
				hidden_[n + 1].table[i][0] = sigmoid(tempHH.table[i][0]);
			}
		}

		// Hidden to outputs
		Matrix tempHO = Matrix.multiply(weightsHO_, hidden_[hidden_.length - 1]);
		tempHO = Matrix.add(tempHO, weightBO_);
		for (int i = 0; i < tempHO.rows; i++) {
			for (int j = 0; j < tempHO.cols; j++) {
				outputs_.table[i][j] = sigmoid(tempHO.table[i][j]);
			}
		}
		return outputs_.toArray();
	}

	private float[] guessTraining(float[] in) {
		inputs = new Matrix(in);

		// Input to hidden
		Matrix tempIH = Matrix.multiply(weightsIH, inputs);
		tempIH = Matrix.add(tempIH, weightBI);
		for (int i = 0; i < tempIH.rows; i++) {
			hidden[0].table[i][0] = sigmoid(tempIH.table[i][0]);
		}

		// Hidden to hidden
		for (int n = 0; n < weightsHH.length; n++) {
			Matrix tempHH = Matrix.multiply(weightsHH[n], hidden[n]);
			tempHH = Matrix.add(tempHH, weightsBH[n]);
			for (int i = 0; i < tempHH.rows; i++) {
				hidden[n + 1].table[i][0] = sigmoid(tempHH.table[i][0]);
			}
		}

		// Hidden to outputs
		Matrix tempHO = Matrix.multiply(weightsHO, hidden[hidden.length - 1]);
		tempHO = Matrix.add(tempHO, weightBO);
		for (int i = 0; i < tempHO.rows; i++) {
			for (int j = 0; j < tempHO.cols; j++) {
				outputs.table[i][j] = sigmoid(tempHO.table[i][j]);
			}
		}
		return outputs.toArray();
	}

	public void train(float[] inputs_, float[] answers_) {
		float[] predicted = guessTraining(inputs_);
		Matrix predictions = new Matrix(predicted);
		Matrix answers = new Matrix(answers_);

		// Calc errors
		// Output to Hidden
		Matrix errorsO = Matrix.subtract(answers, predictions);
		Matrix transposedHO = Matrix.transpose(weightsHO);
		Matrix errorsHLast = Matrix.multiply(transposedHO, errorsO);

		// Hidden to Hidden
		Matrix[] errorsH = new Matrix[hidden.length];
		errorsH[hidden.length - 1] = errorsHLast;

		for (int n = hidden.length - 2; n >= 0; n--) {
			Matrix transposedHH = Matrix.transpose(weightsHH[n]);
			errorsH[n] = Matrix.multiply(transposedHH, errorsH[n + 1]);
		}

		// Adjust weights
		// Output to hidden
		Matrix gradient = new Matrix(outputs.rows, outputs.cols);
		for (int i = 0; i < outputs.rows; i++) {
			for (int j = 0; j < outputs.cols; j++) {
				gradient.table[i][j] = dsigmoid(outputs.table[i][j]);// outputs.table[i][j]*(1-outputs.table[i][j]);
			}
		}

		// Multiply error and lr
		gradient.multiply(errorsO);
		gradient.multiply(learningrate);
		// Adjust weights
		weightBO = Matrix.add(weightBO, gradient);
		Matrix hiddenLastT = Matrix.transpose(hidden[hidden.length - 1]);
		Matrix deltaWeightsHO = Matrix.multiply(gradient, hiddenLastT);
		weightsHO = Matrix.add(weightsHO, deltaWeightsHO);

		// Hidden to hidden
		for (int n = hidden.length - 1; n >= 1; n--) {
			gradient = new Matrix(hidden[n].rows, hidden[n].cols);
			for (int i = 0; i < gradient.rows; i++) {
				for (int j = 0; j < gradient.cols; j++) {
					gradient.table[i][j] = hidden[n].table[i][j] * (1 - hidden[n].table[i][j]);
				}
			}
			gradient.multiply(errorsH[n]);
			gradient.multiply(learningrate);
			weightsBH[n - 1] = Matrix.add(weightsBH[n - 1], gradient);
			weightsHH[n - 1] = Matrix.add(weightsHH[n - 1], Matrix.multiply(gradient, Matrix.transpose(hidden[n - 1])));
		}

		// Hidden to inputs
		gradient = new Matrix(hidden[0].rows, hidden[0].cols);
		for (int i = 0; i < gradient.rows; i++) {
			for (int j = 0; j < gradient.cols; j++) {
				gradient.table[i][j] = hidden[0].table[i][j] * (1 - hidden[0].table[i][j]);
			}
		}

		// Multiply error and lr
		gradient.multiply(errorsH[0]);
		gradient.multiply(learningrate);

		// Adjust weights
		weightBI = Matrix.add(weightBI, gradient);
		weightsIH = Matrix.add(weightsIH, Matrix.multiply(gradient, Matrix.transpose(inputs)));
	}
}
