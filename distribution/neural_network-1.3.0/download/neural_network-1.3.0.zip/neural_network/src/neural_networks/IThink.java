package neural_networks;

public interface IThink {
	void thinkWrapper();
}
