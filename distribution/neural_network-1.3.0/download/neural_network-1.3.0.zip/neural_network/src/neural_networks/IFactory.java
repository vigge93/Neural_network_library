package neural_networks;

public interface IFactory<T> {
	T Factory();
}
