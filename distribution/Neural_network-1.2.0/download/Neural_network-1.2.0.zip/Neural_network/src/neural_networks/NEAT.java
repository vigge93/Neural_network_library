package neural_networks;

import java.io.Serializable;

public class NEAT extends ENN implements Serializable {

	private static final long serialVersionUID = 1L;
	
	int specie;
	
	NEAT(){
		super(1, new int[] {1}, 1, "NEAT");
	}
	
	
	
	/**
	 * To be added
	 * @param old
	 * @return
	 */
	NEAT[] crossover(NEAT[] old) {
		return null;
	}
	
}
